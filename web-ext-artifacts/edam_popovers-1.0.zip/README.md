# EDAM Popovers

**Firefox extension that adds popovers with the detailed information to EDAM terms.**

https://addons.mozilla.org/en-US/firefox/addon/edam-popovers/

<img src="https://pbs.twimg.com/media/D-xw245WkAAN7Tq?format=jpg&name=4096x4096" alt="EDAM Popovers mock-up" height="300"/><img src="https://addons.cdn.mozilla.net/user-media/previews/full/222/222432.png" alt="EDAM Popovers screenshot" height="300"/>

## Authors

- Ivan Kuzmin [@inkuzmin](https://twitter.com/inkuzmin)
- Matúš Kalaš [@matuskalas](https://twitter.com/matuskalas)
- Hervé Ménager [@rvmngr](https://twitter.com/rvmngr)

## Licenses

MIT
